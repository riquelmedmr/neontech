import React from 'react'

export default function Contact() {
  return (
    <div className="p-10">
      <h2 className="text-3xl font-bold mb-4">Fale Conosco</h2>
      <p>Envie um email para contato@neontech.com ou preencha nosso formulário.</p>
    </div>
  )
}
