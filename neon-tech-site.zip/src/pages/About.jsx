import React from 'react'

export default function About() {
  return (
    <div className="p-10">
      <h2 className="text-3xl font-bold mb-4">Sobre Nós</h2>
      <p>Somos apaixonados por inovação, design e experiências digitais únicas.</p>
    </div>
  )
}
